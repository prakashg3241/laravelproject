<div style="clear:both" class="panel panel-default">
    
    
  </div>
<?php /**PATH C:\xampp\htdocs\laravels\mvc\resources\views/footer.blade.php ENDPATH**/ ?>