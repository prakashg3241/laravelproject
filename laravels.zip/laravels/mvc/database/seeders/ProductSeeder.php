<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('products')->insert([
            [ 'id'=>1,
                'name'=>'Oppo mobile',
                "price"=>"300",
                "description"=>"A smartphone with 8gb ram and much more feature",
                "category"=>"mobile",
                "gallery"=>"https://www.freepnglogos.com/uploads/mobile-png/samsung-mobile-png-14.png "
            ],
            [ 'id'=>2,
                'name'=>'Panasonic Tv',
                "price"=>"400",
                "description"=>"Panasonic 100 cm (40 inch) Full HD LED Smart Android TV ",
                "category"=>"Tv",
                "gallery"=>"https://www.pngall.com/wp-content/uploads/5/Samsung-TV-PNG.png"
            ],
            [  'id'=>3,
                'name'=>'Soni Tv',
                "price"=>"500",
                "description"=>"Soni 120 cm (43 inch) Full HD LED Smart Android TV",
                "category"=>"tv",
                "gallery"=>"https://rukminim1.flixcart.com/image/416/416/kbpeoi80/television/h/w/n/sony-kdl-32w6100-kdl-32w6103-original-imafszz3rmvj6xdg.jpeg?q=70"
            ],
            [ 'id'=>4,
                'name'=>'LG fridge',
                "price"=>"200",
                "description"=>"LG 190 L Direct Cool Single Door 5 Star Refrigerator with Base Drawer with Smart Inverter Compressor  (Light Red)",
                "category"=>"fridge",
                "gallery"=>"https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTFx-2-wTOcfr5at01ojZWduXEm5cZ-sRYPJA&usqp=CAU"
        ],
             [ 'id'=>5,
                'name'=>'Samsung mobile',
                "price"=>"300",
                "description"=>"SAMSUNG Galaxy F23 5G (Aqua Blue, 128 GB)  (6 GB RAM)",
                "category"=>"mobile",
                "gallery"=>"https://assetscdn1.paytm.com/images/catalog/product/M/MO/MOBOPPO-A52-6-GFUTU6297453D3D253C/1592019058170_0..png "
            ],
            [ 'id'=>6,
                'name'=>'Sky Bags',
                "price"=>"200",
                "description"=>"Medium 26 L Backpack Boho 03  (Red) ",
                "category"=>"Bags",
                "gallery"=>"https://pngfile.net/public/uploads/preview/sky-bags-backpack-red-11589321436buoxjgj8lb.png"
            ],
            [  'id'=>7,
                'name'=>'Acer Laptop',
                "price"=>"700",
                "description"=>"Acer Aspire 7 Core i5 10th Gen - (8 GB/512 GB SSD/Windows 10 Home/4 GB Graphics/NVIDIA GeForce GTX 1650) A715-75G-50TA/ A715-75G-41G/ A715-75G-52AA Gaming Laptop  (15.6 inch, Black, 2.15 Kg)",
                "category"=>"laptop",
                "gallery"=>"https://e7.pngegg.com/pngimages/398/672/png-clipart-gray-acer-laptop-laptop-laptop-notebook-electronics-gadget.png"
            ],
            [ 'id'=>8,
                'name'=>'Sky Bags',
                "price"=>"200",
                "description"=>"Medium 28 L Backpack Boho 03  (black)",
                "category"=>"Bags",
                "gallery"=>"https://rukminim1.flixcart.com/image/880/1056/kn97te80/backpack/f/8/o/boho-03-bpboh3gry-backpack-skybags-original-imagfyx4m85wp6te.jpeg?q=50"
        ],
        ['id'=>9,
                'name'=>'Lenovo Laptop',
                "price"=>"700",
                "description"=>"Lenovo IdeaPad 3 Core i5 10th Gen - (8 GB/256 GB SSD/Windows 11 Home) Thin and Light Laptop  (15.6 Inch, Platinum Grey )",
                "category"=>"laptop",
                "gallery"=>"https://rukminim1.flixcart.com/image/416/416/keaaavk0/computer/x/m/y/lenovo-na-laptop-original-imafuzt8r5jqppfn.jpeg?q=70 "
            ],
            [ 'id'=>10,
                'name'=>'Vivo mobile',
                "price"=>"300",
                "description"=>"vivo T1 5G (Rainbow Fantasy, 128 GB)  (6 GB RAM) ",
                "category"=>"mobile",
                "gallery"=>"https://rukminim1.flixcart.com/image/416/416/kzd147k0/mobile/m/c/f/-original-imagbe5qknarjywp.jpeg?q=70"
            ]
             
        ]);
    }
}
